<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/categories', [\App\Http\Controllers\CategoryController::class, 'store']);
Route::post('/products', [\App\Http\Controllers\ProductController::class, 'store']);
